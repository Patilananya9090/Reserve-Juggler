"""CVaR multi-period portfolio optimizer using cvxpy."""
import numpy as np
import pandas as pd
import cvxpy as cp


def optimize_portfolio(
    df: pd.DataFrame,
    total_aum: float,
    horizon_hours: int = 24,
    risk_lambda: float = 2.0,
    permanent_capital_pct: float = 0.10,
    min_cash_pct: float = 0.05,
    cvar_alpha: float = 0.95,
    n_scenarios: int = 200,
) -> dict:
    """
    Optimize allocation across [cash, repo, bonds, equities] by maximizing
    expected yield - lambda * CVaR(95%) of shortfall.
    """
    latest = df.iloc[-1]
    repo_rate = float(latest["tier1_repo_rate_apy"]) / 100
    bond_yield = float(latest["tier2_bond_yield_pct"]) / 100
    bond_duration = float(latest["tier2_bond_mod_duration"])
    stock_vol = float(latest["tier3_stock_volatility_pct"]) / 100
    overdraft_rate = float(latest["emergency_overdraft_penalty_apr_pct"]) / 100
    repo_haircut = float(latest["tier1_early_redemption_haircut_pct"]) / 100
    bond_haircut = float(latest["tier2_bond_liquidation_haircut_pct"]) / 100
    equity_haircut = float(latest["tier3_stock_liquidation_haircut_pct"]) / 100

    # Annualized returns per tier (hourly fraction for horizon)
    h_frac = horizon_hours / 8760
    r_cash = 0.0
    r_repo = repo_rate * h_frac
    r_bond = bond_yield * h_frac
    r_equity = 0.10 * h_frac  # expected equity APY

    # Simulate net_flow scenarios for the horizon
    recent_flows = df["net_flow_usd"].tail(24 * 30).values
    rng = np.random.default_rng(42)
    scenario_flows = rng.choice(recent_flows, size=(n_scenarios, horizon_hours), replace=True)
    cum_outflows = -scenario_flows.sum(axis=1)  # negative = cash drain

    # Decision variables: allocation fractions
    w = cp.Variable(4, nonneg=True)  # [cash, repo, bonds, equities]

    # Allocations in USD
    allocs = w * total_aum

    # Constraints
    constraints = [
        cp.sum(w) == 1,
        w[0] >= min_cash_pct,                       # minimum cash floor
        w[3] <= permanent_capital_pct,               # equity cap
        w[1] <= 0.70,                                # repo cap
    ]

    # Expected yield (positive = income)
    returns = np.array([r_cash, r_repo, r_bond, r_equity])
    expected_yield = returns @ w * total_aum

    # CVaR of shortfall: for each scenario, shortfall = max(0, outflow - liquid_value)
    # Liquid value = cash + (1-haircut)*repo + (1-haircut)*bonds + (1-haircut)*equities
    liquid_weights = np.array([1.0, 1 - repo_haircut, 1 - bond_haircut, 1 - equity_haircut])

    # Linearize CVaR with auxiliary variable
    var_alpha = cp.Variable()  # VaR
    z = cp.Variable(n_scenarios, nonneg=True)  # excess losses

    liquid_value = (liquid_weights @ w) * total_aum
    shortfalls = np.maximum(cum_outflows - liquid_value.value if liquid_value.value else 0, 0)

    # Proper CVaR linearization
    scenarios_matrix = cum_outflows.reshape(-1, 1)  # (n_scenarios, 1)
    liquid_val = liquid_weights @ w * total_aum
    shortfall_var = scenarios_matrix.flatten() - liquid_val

    cvar_constraints = [
        z >= shortfall_var - var_alpha,
    ]
    cvar = var_alpha + (1 / (n_scenarios * (1 - cvar_alpha))) * cp.sum(z)

    objective = cp.Maximize(expected_yield - risk_lambda * cvar)
    prob = cp.Problem(objective, constraints + cvar_constraints)

    try:
        prob.solve(solver=cp.SCS, verbose=False)
        if w.value is None:
            raise ValueError("Solver returned None")
        alloc_frac = w.value
    except Exception:
        # Fallback: equal-weight with constraints satisfied
        alloc_frac = np.array([min_cash_pct, 0.50, 0.30, permanent_capital_pct])
        alloc_frac = alloc_frac / alloc_frac.sum()

    alloc_usd = alloc_frac * total_aum
    exp_yield_usd = float(returns @ alloc_frac * total_aum)
    cvar_usd = float(max(0, -expected_yield.value if hasattr(expected_yield, "value") and expected_yield.value else 0))

    return {
        "horizon_hours": horizon_hours,
        "total_aum_usd": round(total_aum, 2),
        "allocations": {
            "cash_usd": round(float(alloc_usd[0]), 2),
            "repo_usd": round(float(alloc_usd[1]), 2),
            "bonds_usd": round(float(alloc_usd[2]), 2),
            "equities_usd": round(float(alloc_usd[3]), 2),
        },
        "weights_pct": {
            "cash": round(float(alloc_frac[0]) * 100, 2),
            "repo": round(float(alloc_frac[1]) * 100, 2),
            "bonds": round(float(alloc_frac[2]) * 100, 2),
            "equities": round(float(alloc_frac[3]) * 100, 2),
        },
        "expected_yield_usd_horizon": round(exp_yield_usd, 2),
        "cvar_95_usd": round(cvar_usd, 2),
        "annualized_yield_pct": round(
            (exp_yield_usd / total_aum) / h_frac * 100, 4
        ) if h_frac > 0 else 0,
        "risk_lambda": risk_lambda,
    }

"""Simulate the full year with newsvendor strategy vs naive 20% cash strategy."""
import numpy as np
import pandas as pd
from forecaster import train_forecaster, QUANTILES, FEATURES, _models, _conformal_adjustments
import lightgbm as lgb


TOTAL_AUM = 500_000_000  # $500M AUM


def run_backtest(df: pd.DataFrame) -> dict:
    # Ensure models trained
    train_forecaster(df)

    sweep_rows = df[df["hour"] == 17].dropna(subset=["overnight_cum_outflow"]).copy()
    sweep_rows = sweep_rows.reset_index(drop=True)

    results = []

    for _, row in sweep_rows.iterrows():
        actual_outflow = float(row["overnight_cum_outflow"])
        repo_rate = float(row["tier1_repo_rate_apy"]) / 100
        overdraft_rate = float(row["emergency_overdraft_penalty_apr_pct"]) / 100
        repo_haircut = float(row["tier1_early_redemption_haircut_pct"]) / 100

        # --- Newsvendor strategy ---
        c_u = overdraft_rate / 8760
        c_o = repo_rate / 8760
        q_star = c_u / (c_u + c_o)

        X = row[FEATURES].values.reshape(1, -1)
        qs = np.array(QUANTILES)
        vals = np.array([_models[q].predict(X)[0] + _conformal_adjustments.get(q, 0) for q in QUANTILES])
        b_star = float(np.interp(q_star, qs, vals))
        b_star = max(b_star, 0)
        sweep = max(TOTAL_AUM - b_star, 0)

        # Revenue from repo overnight (15 hrs ≈ 15/8760 of annual)
        repo_income = sweep * repo_rate * (15 / 8760)
        # Shortfall cost
        cash_available = TOTAL_AUM - sweep
        shortfall = max(actual_outflow - cash_available, 0)
        overdraft_cost = shortfall * overdraft_rate * (15 / 8760)
        # Early-break cost if we needed to crack repo
        crack_repo = min(shortfall, sweep)
        crack_cost = crack_repo * repo_haircut

        nv_net = repo_income - overdraft_cost - crack_cost

        # --- Naive strategy: always hold 20% cash ---
        naive_cash = 0.20 * TOTAL_AUM
        naive_sweep = TOTAL_AUM - naive_cash
        naive_repo_income = naive_sweep * repo_rate * (15 / 8760)
        naive_shortfall = max(actual_outflow - naive_cash, 0)
        naive_overdraft = naive_shortfall * overdraft_rate * (15 / 8760)
        naive_crack = min(naive_shortfall, naive_sweep) * repo_haircut
        naive_net = naive_repo_income - naive_overdraft - naive_crack

        results.append({
            "timestamp": str(row["timestamp"]),
            "actual_outflow": actual_outflow,
            "nv_cash_buffer": b_star,
            "nv_sweep": sweep,
            "nv_net_pnl": nv_net,
            "naive_net_pnl": naive_net,
            "nv_overdraft": overdraft_cost > 0,
            "naive_overdraft": naive_overdraft > 0,
        })

    res = pd.DataFrame(results)

    def sharpe(pnl: pd.Series) -> float:
        if pnl.std() == 0:
            return 0.0
        return float((pnl.mean() / pnl.std()) * np.sqrt(365))

    total_days = len(res)

    return {
        "total_days": total_days,
        "newsvendor": {
            "total_pnl_usd": round(float(res["nv_net_pnl"].sum()), 2),
            "avg_daily_pnl_usd": round(float(res["nv_net_pnl"].mean()), 2),
            "sharpe_ratio": round(sharpe(res["nv_net_pnl"]), 4),
            "overdraft_events": int(res["nv_overdraft"].sum()),
            "overdraft_rate_pct": round(res["nv_overdraft"].mean() * 100, 2),
            "max_single_loss_usd": round(float(res["nv_net_pnl"].min()), 2),
            "annualized_yield_pct": round(
                float(res["nv_net_pnl"].sum()) / TOTAL_AUM * (365 / (total_days or 1)) * 100, 4
            ),
        },
        "naive": {
            "total_pnl_usd": round(float(res["naive_net_pnl"].sum()), 2),
            "avg_daily_pnl_usd": round(float(res["naive_net_pnl"].mean()), 2),
            "sharpe_ratio": round(sharpe(res["naive_net_pnl"]), 4),
            "overdraft_events": int(res["naive_overdraft"].sum()),
            "overdraft_rate_pct": round(res["naive_overdraft"].mean() * 100, 2),
            "max_single_loss_usd": round(float(res["naive_net_pnl"].min()), 2),
            "annualized_yield_pct": round(
                float(res["naive_net_pnl"].sum()) / TOTAL_AUM * (365 / (total_days or 1)) * 100, 4
            ),
        },
        "advantage_pct": round(
            (res["nv_net_pnl"].sum() - res["naive_net_pnl"].sum()) / TOTAL_AUM * 100, 4
        ),
        "daily_pnl": [
            {
                "timestamp": r["timestamp"],
                "newsvendor_pnl": round(r["nv_net_pnl"], 2),
                "naive_pnl": round(r["naive_net_pnl"], 2),
            }
            for r in results
        ],
        "penalty_heatmap": _build_heatmap(results),
    }


def _build_heatmap(results: list[dict]) -> list[dict]:
    """Build penalty heat map: quantile chosen vs actual outflow bucket."""
    repo_rate = 0.043 / 8760
    overdraft_rate = 0.12 / 8760
    c_u = overdraft_rate
    c_o = repo_rate

    q_grid = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    outflow_vals = [r["actual_outflow"] for r in results]
    p10, p90 = np.percentile(outflow_vals, 10), np.percentile(outflow_vals, 90)
    outflow_buckets = np.linspace(p10, p90, 9)

    cells = []
    for q in q_grid:
        for ob in outflow_buckets:
            b = TOTAL_AUM * q  # cash held = fraction of AUM (simplified)
            shortfall = max(ob - b, 0)
            excess = max(b - ob, 0)
            cost = shortfall * c_u + excess * c_o
            cells.append({
                "quantile": round(q, 2),
                "outflow_bucket": round(float(ob), 0),
                "total_cost": round(cost * TOTAL_AUM, 2),
            })
    return cells


def simulate_stress(
    df: pd.DataFrame,
    withdrawal_multiplier: float = 3.0,
    shock_start_hour: int = 22,
    shock_duration_hours: int = 6,
    current_cash_usd: float = 50_000_000,
    current_repo_usd: float = 300_000_000,
    current_bonds_usd: float = 100_000_000,
    current_equities_usd: float = 50_000_000,
) -> dict:
    """Forward-simulate a withdrawal shock and show tier cascade."""
    latest = df.iloc[-1]
    avg_hourly_withdrawal = float(df["withdrawals_usd"].tail(24 * 7).mean())
    shock_withdrawal = avg_hourly_withdrawal * withdrawal_multiplier
    total_shock = shock_withdrawal * shock_duration_hours

    repo_haircut = float(latest["tier1_early_redemption_haircut_pct"]) / 100
    bond_haircut = float(latest["tier2_bond_liquidation_haircut_pct"]) / 100
    equity_haircut = float(latest["tier3_stock_liquidation_haircut_pct"]) / 100
    overdraft_rate = float(latest["emergency_overdraft_penalty_apr_pct"]) / 100

    remaining = total_shock
    cascade = []
    total_penalty = 0.0

    # Tier 0: Cash
    cash_used = min(remaining, current_cash_usd)
    remaining -= cash_used
    cascade.append({"tier": "Cash (Tier 0)", "used_usd": round(cash_used, 2), "penalty_usd": 0, "haircut_pct": 0})

    # Tier 1: Repo (crack early)
    if remaining > 0:
        repo_available = current_repo_usd
        repo_used = min(remaining, repo_available)
        penalty = repo_used * repo_haircut
        total_penalty += penalty
        remaining -= repo_used
        cascade.append({"tier": "Repo Crack (Tier 1)", "used_usd": round(repo_used, 2), "penalty_usd": round(penalty, 2), "haircut_pct": repo_haircut * 100})

    # Tier 2: Bond liquidation
    if remaining > 0:
        bond_available = current_bonds_usd * (1 - bond_haircut)
        bond_gross = min(remaining / (1 - bond_haircut), current_bonds_usd)
        penalty = bond_gross * bond_haircut
        total_penalty += penalty
        remaining -= min(remaining, bond_available)
        cascade.append({"tier": "Bond Liquidation (Tier 2)", "used_usd": round(bond_gross, 2), "penalty_usd": round(penalty, 2), "haircut_pct": bond_haircut * 100})

    # Tier 3: Equity fire-sale
    if remaining > 0:
        eq_available = current_equities_usd * (1 - equity_haircut)
        eq_gross = min(remaining / (1 - equity_haircut), current_equities_usd)
        penalty = eq_gross * equity_haircut
        total_penalty += penalty
        remaining -= min(remaining, eq_available)
        cascade.append({"tier": "Equity Fire-Sale (Tier 3)", "used_usd": round(eq_gross, 2), "penalty_usd": round(penalty, 2), "haircut_pct": equity_haircut * 100})

    # Overdraft
    if remaining > 0:
        od_hours = shock_duration_hours
        overdraft_penalty = remaining * overdraft_rate * od_hours / 8760
        total_penalty += overdraft_penalty
        cascade.append({"tier": "Overdraft (Central Bank)", "used_usd": round(remaining, 2), "penalty_usd": round(overdraft_penalty, 2), "haircut_pct": overdraft_rate * 100})
        survived = False
    else:
        survived = True

    return {
        "scenario": {
            "withdrawal_multiplier": withdrawal_multiplier,
            "shock_start_hour": shock_start_hour,
            "shock_duration_hours": shock_duration_hours,
            "total_shock_usd": round(total_shock, 2),
            "avg_hourly_withdrawal_usd": round(avg_hourly_withdrawal, 2),
        },
        "cascade": cascade,
        "total_penalty_usd": round(total_penalty, 2),
        "survived": survived,
        "residual_shortfall_usd": round(max(remaining, 0), 2),
    }

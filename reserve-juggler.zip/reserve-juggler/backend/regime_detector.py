"""2-state Gaussian Mixture regime detector + CUSUM change-point on net_flow variance."""
import numpy as np
import pandas as pd
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler


_gmm: GaussianMixture | None = None
_scaler: StandardScaler | None = None
_regime_labels: np.ndarray | None = None


def fit_regime(df: pd.DataFrame):
    global _gmm, _scaler, _regime_labels

    X = df[["net_flow_usd", "tier3_stock_volatility_pct"]].values.astype(float)
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)

    model = GaussianMixture(n_components=2, covariance_type="full", random_state=42, n_init=3)
    model.fit(Xs)
    labels = model.predict(Xs)

    # Ensure state 1 = stress: the component with higher volatility mean (in original space)
    vol_by_state = [
        X[labels == s, 1].mean() if (labels == s).any() else 0.0
        for s in range(2)
    ]
    if vol_by_state[0] > vol_by_state[1]:
        labels = 1 - labels

    _gmm = model
    _scaler = scaler
    _regime_labels = labels
    return labels


def get_regime_series(df: pd.DataFrame) -> pd.Series:
    if _regime_labels is None:
        fit_regime(df)
    return pd.Series(_regime_labels, index=df.index, name="regime")


def current_regime(df: pd.DataFrame) -> dict:
    if _regime_labels is None:
        fit_regime(df)

    labels = _regime_labels
    latest_state = int(labels[-1])

    # Posterior probability of stress state
    Xs = _scaler.transform(
        df[["net_flow_usd", "tier3_stock_volatility_pct"]].values[-1:].astype(float)
    )
    probs = _gmm.predict_proba(Xs)[0]

    # Map component index to stress/normal (stress = higher vol component)
    means_vol = [_gmm.means_[s, 1] for s in range(2)]
    stress_component = int(np.argmax(means_vol))
    stress_prob = float(probs[stress_component])

    # CUSUM secondary signal: rolling variance spike
    roll_var = df["net_flow_usd"].rolling(24).var().fillna(0)
    cusum_signal = int(roll_var.iloc[-1] > roll_var.quantile(0.85))

    # Count hours in current state
    hours_in_state = 0
    for lbl in reversed(labels):
        if lbl == latest_state:
            hours_in_state += 1
        else:
            break

    return {
        "state": latest_state,
        "label": "STRESS" if latest_state == 1 else "NORMAL",
        "stress_probability": round(stress_prob, 4),
        "cusum_alert": bool(cusum_signal),
        "hours_in_current_state": hours_in_state,
        "quantile_adjustment": 0.10 if latest_state == 1 else 0.0,
    }


def regime_history(df: pd.DataFrame) -> list[dict]:
    if _regime_labels is None:
        fit_regime(df)
    labels = _regime_labels
    return [
        {
            "timestamp": str(df["timestamp"].iloc[i]),
            "regime": int(labels[i]),
            "net_flow": float(df["net_flow_usd"].iloc[i]),
        }
        for i in range(0, len(df), 6)
    ]

import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import Forecast from './pages/Forecast'
import Optimizer from './pages/Optimizer'
import Sleeves from './pages/Sleeves'
import Regime from './pages/Regime'
import Metrics from './pages/Metrics'

const navItems = [
  { to: '/', label: 'Dashboard' },
  { to: '/forecast', label: 'Forecast' },
  { to: '/optimizer', label: 'Optimizer' },
  { to: '/sleeves', label: 'Sleeves' },
  { to: '/regime', label: 'Regime & Stress' },
  { to: '/metrics', label: 'Metrics' },
]

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen flex flex-col">
        {/* Top nav */}
        <nav className="bg-slate-900 border-b border-slate-700 px-6 py-3 flex items-center gap-6 sticky top-0 z-50">
          <span className="text-blue-400 font-bold text-lg tracking-tight mr-4">
            ⚖️ Reserve Juggler
          </span>
          {navItems.map(({ to, label }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              className={({ isActive }) =>
                `text-sm font-medium transition-colors ${
                  isActive
                    ? 'text-blue-400 border-b-2 border-blue-400 pb-0.5'
                    : 'text-slate-400 hover:text-white'
                }`
              }
            >
              {label}
            </NavLink>
          ))}
        </nav>

        {/* Page content */}
        <main className="flex-1 p-6">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/forecast" element={<Forecast />} />
            <Route path="/optimizer" element={<Optimizer />} />
            <Route path="/sleeves" element={<Sleeves />} />
            <Route path="/regime" element={<Regime />} />
            <Route path="/metrics" element={<Metrics />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}

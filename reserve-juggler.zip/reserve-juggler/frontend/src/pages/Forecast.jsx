import { useEffect, useState } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, ReferenceLine } from 'recharts'

function fmt(n) {
  if (n >= 1e6) return `$${(n / 1e6).toFixed(2)}M`
  if (n >= 1e3) return `$${(n / 1e3).toFixed(1)}K`
  return `$${n?.toFixed(0) ?? 0}`
}

const Q_LABELS = { q05: 'p5', q10: 'p10', q25: 'p25', q50: 'Median', q75: 'p75', q90: 'p90', q95: 'p95' }
const Q_COLORS = ['#7dd3fc', '#60a5fa', '#3b82f6', '#2563eb', '#1d4ed8', '#1e40af', '#1e3a8a']

export default function Forecast() {
  const [forecast, setForecast] = useState(null)
  const [sweep, setSweep] = useState(null)
  const [coverage, setCoverage] = useState(null)

  useEffect(() => {
    fetch('/api/forecast').then(r => r.json()).then(setForecast)
    fetch('/api/sweep').then(r => r.json()).then(setSweep)
    fetch('/api/coverage').then(r => r.json()).then(setCoverage)
  }, [])

  if (!forecast || !sweep) return <div className="text-slate-400 text-center mt-20">Loading forecast…</div>

  const chartData = Object.entries(Q_LABELS).map(([key, label], i) => ({
    label,
    value: forecast[key] || 0,
    fill: Q_COLORS[i],
  }))

  const optimalQ = sweep.optimal_quantile_adjusted
  const optimalBar = Math.round(optimalQ * (chartData.length - 1))

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Overnight Outflow Forecast</h1>
      <p className="text-slate-400 text-sm">Distribution of cumulative net outflow from 17:00 → 08:00 next morning. Calibrated with conformal intervals.</p>

      {/* Fan chart */}
      <div className="card">
        <h2 className="text-sm font-semibold text-slate-300 mb-4">Forecast Quantile Distribution</h2>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={chartData} margin={{ left: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="label" tick={{ fill: '#94a3b8', fontSize: 12 }} />
            <YAxis tickFormatter={v => `${(v/1e6).toFixed(1)}M`} tick={{ fill: '#94a3b8', fontSize: 10 }} />
            <Tooltip formatter={v => fmt(v)} contentStyle={{ background: '#1e293b', border: '1px solid #475569' }} />
            <Bar dataKey="value" radius={[4, 4, 0, 0]}>
              {chartData.map((d, i) => <Cell key={i} fill={d.fill} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Newsvendor sweep recommendation */}
      {sweep && (
        <div className="card border-blue-500">
          <h2 className="text-sm font-semibold text-blue-300 mb-4">⚡ Newsvendor Sweep Recommendation</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="stat-label">Optimal Quantile (q*)</p>
              <p className="text-xl font-bold text-blue-400">{(sweep.optimal_quantile_adjusted * 100).toFixed(1)}%</p>
              <p className="text-xs text-slate-500 mt-1">c_u / (c_u + c_o)</p>
            </div>
            <div>
              <p className="stat-label">Cash Buffer (B*)</p>
              <p className="text-xl font-bold text-white">{fmt(sweep.optimal_cash_buffer_usd)}</p>
            </div>
            <div>
              <p className="stat-label">Sweep to Repo</p>
              <p className="text-xl font-bold text-green-400">{fmt(sweep.sweep_to_repo_usd)}</p>
            </div>
            <div>
              <p className="stat-label">Overdraft APR</p>
              <p className="text-xl font-bold text-red-400">{sweep.overdraft_penalty_apr_pct}%</p>
            </div>
          </div>
          <div className="mt-4 bg-slate-900 rounded-lg p-3 text-xs text-slate-400">
            <strong className="text-slate-200">Formula:</strong>{' '}
            q* = c_u / (c_u + c_o) = {sweep.c_u_per_hour.toExponential(3)} / ({sweep.c_u_per_hour.toExponential(3)} + {sweep.c_o_per_hour.toExponential(3)}) = <strong className="text-blue-300">{(sweep.optimal_quantile * 100).toFixed(2)}%</strong>
            {' '}(+{((sweep.optimal_quantile_adjusted - sweep.optimal_quantile) * 100).toFixed(1)}% regime adj)
          </div>
        </div>
      )}

      {/* Conformal coverage */}
      {coverage && (
        <div className="card">
          <h2 className="text-sm font-semibold text-slate-300 mb-4">Conformal Coverage Gauge</h2>
          <div className="grid grid-cols-3 md:grid-cols-7 gap-2">
            {Object.entries(coverage).map(([key, v]) => {
              const drift = v.drift
              const color = Math.abs(drift) < 0.03 ? 'green' : Math.abs(drift) < 0.08 ? 'yellow' : 'red'
              return (
                <div key={key} className={`rounded-lg p-2 text-center border ${
                  color === 'green' ? 'bg-green-900/30 border-green-700' :
                  color === 'yellow' ? 'bg-yellow-900/30 border-yellow-600' :
                  'bg-red-900/30 border-red-600'
                }`}>
                  <p className="text-xs text-slate-400">{Q_LABELS[key] || key}</p>
                  <p className="font-bold text-sm text-white">{(v.empirical * 100).toFixed(0)}%</p>
                  <p className={`text-xs ${drift >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {drift >= 0 ? '+' : ''}{(drift * 100).toFixed(1)}%
                  </p>
                </div>
              )
            })}
          </div>
          <p className="text-xs text-slate-500 mt-3">Empirical vs nominal quantile coverage on hold-out test set. Red = miscalibrated, needs retraining.</p>
        </div>
      )}
    </div>
  )
}

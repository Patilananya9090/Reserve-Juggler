import { useEffect, useState } from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, ScatterChart, Scatter, ZAxis } from 'recharts'

function fmt(n) {
  if (n >= 1e6) return `$${(n/1e6).toFixed(2)}M`
  if (n >= 1e3) return `$${(n/1e3).toFixed(1)}K`
  return `$${n?.toFixed(2)}`
}

export default function Metrics() {
  const [metrics, setMetrics] = useState(null)

  useEffect(() => {
    fetch('/api/metrics').then(r => r.json()).then(setMetrics)
  }, [])

  if (!metrics) return <div className="text-slate-400 text-center mt-20">Loading backtest results… (may take a moment)</div>

  const nv = metrics.newsvendor
  const naive = metrics.naive

  const cumulativeData = (metrics.daily_pnl || []).reduce((acc, d, i) => {
    const prev = acc[i - 1] || { nv_cum: 0, naive_cum: 0 }
    acc.push({
      date: d.timestamp.slice(0, 10),
      nv_cum: prev.nv_cum + d.newsvendor_pnl,
      naive_cum: prev.naive_cum + d.naive_pnl,
    })
    return acc
  }, [])

  // Penalty heatmap data
  const heatmap = metrics.penalty_heatmap || []
  const uniqueOutflows = [...new Set(heatmap.map(d => d.outflow_bucket))].sort((a,b)=>a-b)
  const uniqueQuantiles = [...new Set(heatmap.map(d => d.quantile))].sort((a,b)=>a-b)

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Backtested Performance</h1>
      <p className="text-slate-400 text-sm">Full-year simulation: Newsvendor strategy vs naive 20% cash buffer. {metrics.total_days} trading days.</p>

      {/* Comparison table */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[['Newsvendor Strategy', nv, 'blue'], ['Naive 20% Cash', naive, 'slate']].map(([label, data, color]) => (
          <div key={label} className={`card border-${color}-600`}>
            <h2 className={`text-sm font-semibold text-${color}-300 mb-4`}>{label}</h2>
            <div className="grid grid-cols-2 gap-3">
              {[
                ['Total P&L', fmt(data.total_pnl_usd), 'text-green-400'],
                ['Avg Daily P&L', fmt(data.avg_daily_pnl_usd), 'text-white'],
                ['Sharpe Ratio', data.sharpe_ratio.toFixed(3), 'text-white'],
                ['Annualized Yield', `${data.annualized_yield_pct.toFixed(4)}%`, 'text-white'],
                ['Overdraft Events', data.overdraft_events, data.overdraft_events > 0 ? 'text-red-400' : 'text-green-400'],
                ['Overdraft Rate', `${data.overdraft_rate_pct.toFixed(2)}%`, data.overdraft_rate_pct > 1 ? 'text-red-400' : 'text-green-400'],
                ['Worst Day', fmt(data.max_single_loss_usd), 'text-red-400'],
              ].map(([l, v, cls]) => (
                <div key={l}>
                  <p className="stat-label">{l}</p>
                  <p className={`font-bold text-base ${cls}`}>{v}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="card bg-blue-900/20 border-blue-600">
        <p className="text-blue-300 font-semibold">
          Newsvendor advantage over naive: <span className="text-2xl font-bold text-blue-400">{metrics.advantage_pct > 0 ? '+' : ''}{metrics.advantage_pct.toFixed(4)}%</span> of AUM
          ({fmt(nv.total_pnl_usd - naive.total_pnl_usd)} additional P&L over the year)
        </p>
      </div>

      {/* Cumulative PnL chart */}
      <div className="card">
        <h2 className="text-sm font-semibold text-slate-300 mb-4">Cumulative P&L — Newsvendor vs Naive</h2>
        <ResponsiveContainer width="100%" height={260}>
          <LineChart data={cumulativeData} margin={{ left: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 9 }} interval={30} />
            <YAxis tickFormatter={v => `${(v/1e3).toFixed(0)}K`} tick={{ fill: '#94a3b8', fontSize: 10 }} />
            <Tooltip formatter={v => fmt(v)} contentStyle={{ background: '#1e293b', border: '1px solid #475569' }} />
            <Legend />
            <Line type="monotone" dataKey="nv_cum" stroke="#3b82f6" dot={false} strokeWidth={2} name="Newsvendor" />
            <Line type="monotone" dataKey="naive_cum" stroke="#94a3b8" dot={false} strokeWidth={1.5} strokeDasharray="4 4" name="Naive 20%" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Penalty heat map */}
      <div className="card">
        <h2 className="text-sm font-semibold text-slate-300 mb-2">Penalty Heat Map</h2>
        <p className="text-xs text-slate-500 mb-4">Color = total cost (opportunity cost + overdraft penalty). Hot = expensive. Pick the lightest column for your expected outflow.</p>
        <div className="overflow-x-auto">
          <table className="text-xs w-full border-collapse">
            <thead>
              <tr>
                <th className="text-slate-400 text-left p-1">q \ outflow</th>
                {uniqueOutflows.map(o => (
                  <th key={o} className="text-slate-400 p-1">{(o/1e6).toFixed(1)}M</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {uniqueQuantiles.map(q => (
                <tr key={q}>
                  <td className="text-slate-300 p-1 font-medium">{(q*100).toFixed(0)}%</td>
                  {uniqueOutflows.map(o => {
                    const cell = heatmap.find(h => h.quantile === q && Math.abs(h.outflow_bucket - o) < 1e5)
                    const cost = cell?.total_cost ?? 0
                    const maxCost = Math.max(...heatmap.map(h => h.total_cost))
                    const intensity = maxCost > 0 ? cost / maxCost : 0
                    const r = Math.round(239 * intensity)
                    const g = Math.round(68 * intensity + 130 * (1 - intensity))
                    const b = Math.round(68 * intensity + 200 * (1 - intensity))
                    return (
                      <td key={o} className="p-1 text-center text-white rounded" style={{ background: `rgb(${r},${g},${b})`, opacity: 0.85 }}>
                        {cost > 1000 ? `${(cost/1e3).toFixed(0)}K` : cost.toFixed(0)}
                      </td>
                    )
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

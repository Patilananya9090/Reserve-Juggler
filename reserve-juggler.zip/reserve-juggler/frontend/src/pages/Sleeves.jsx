import { useEffect, useState } from 'react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from 'recharts'

function fmt(n) {
  if (n >= 1e6) return `$${(n/1e6).toFixed(1)}M`
  if (n >= 1e3) return `$${(n/1e3).toFixed(1)}K`
  return `$${n?.toFixed(0)}`
}

export default function Sleeves() {
  const [bonds, setBonds] = useState(null)
  const [equity, setEquity] = useState(null)

  useEffect(() => {
    fetch('/api/bond-sleeve').then(r => r.json()).then(setBonds)
    fetch('/api/equity-sleeve').then(r => r.json()).then(setEquity)
  }, [])

  if (!bonds || !equity) return <div className="text-slate-400 text-center mt-20">Loading sleeves…</div>

  const bucketData = bonds.ladder.map(b => ({
    name: b.bucket,
    notional: b.notional_usd,
    carry: b.carry_annual_usd,
    dv01: b.dv01_usd,
  }))

  const drawdownPct = Math.abs(equity.drawdown_from_peak_pct)
  const drawdownBarWidth = Math.min(drawdownPct / 20 * 100, 100)

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Bond & Equity Sleeves</h1>

      {/* Bond Sleeve */}
      <div className="card">
        <h2 className="text-base font-semibold text-slate-200 mb-1">Bond Sleeve — Maturity Ladder</h2>
        <p className="text-xs text-slate-500 mb-4">dP ≈ −D_mod × dy. Duration-capped per bucket so 100bp rate shock &lt; 1% NAV loss.</p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div>
            <p className="stat-label">Total Notional</p>
            <p className="stat-value">{fmt(bonds.total_bond_notional_usd)}</p>
          </div>
          <div>
            <p className="stat-label">Yield</p>
            <p className="stat-value">{bonds.current_yield_pct.toFixed(3)}%</p>
          </div>
          <div>
            <p className="stat-label">DV01 (total)</p>
            <p className="stat-value">{fmt(bonds.dv01_total_usd)}</p>
          </div>
          <div>
            <p className="stat-label">100bp Price Impact</p>
            <p className="stat-value text-red-400">{bonds.price_impact_100bp_pct.toFixed(3)}%</p>
          </div>
        </div>

        <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium mb-4 ${bonds.carry_beats_rate_shock ? 'bg-green-900/40 text-green-400 border border-green-700' : 'bg-red-900/40 text-red-400 border border-red-700'}`}>
          {bonds.carry_beats_rate_shock ? '✓ Carry beats rate shock' : '✗ Rate shock exceeds carry'} —
          Carry {bonds.carry_annual_pct.toFixed(3)}% vs shock {bonds.rate_shock_loss_pct.toFixed(3)}%
        </div>

        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={bucketData} margin={{ left: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="name" tick={{ fill: '#94a3b8', fontSize: 12 }} />
            <YAxis tickFormatter={v => `${(v/1e6).toFixed(0)}M`} tick={{ fill: '#94a3b8', fontSize: 10 }} />
            <Tooltip formatter={fmt} contentStyle={{ background: '#1e293b', border: '1px solid #475569' }} />
            <Bar dataKey="notional" fill="#10b981" radius={[4,4,0,0]} name="Notional" />
            <Bar dataKey="carry" fill="#34d399" radius={[4,4,0,0]} name="Annual Carry" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Equity Sleeve */}
      <div className={`card ${equity.de_risk_triggered ? 'border-red-500' : 'border-amber-700/50'}`}>
        <h2 className="text-base font-semibold text-slate-200 mb-1">Equity Sleeve</h2>
        <p className="text-xs text-slate-500 mb-4">Only permanent capital deployed. Drawdown-triggered de-risking at {Math.abs(equity.de_risk_threshold_pct)}% drawdown.</p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div>
            <p className="stat-label">Current Price</p>
            <p className="stat-value">{equity.current_stock_price.toFixed(2)}</p>
          </div>
          <div>
            <p className="stat-label">Peak Price</p>
            <p className="stat-value">{equity.peak_stock_price.toFixed(2)}</p>
          </div>
          <div>
            <p className="stat-label">Annualized Vol</p>
            <p className="stat-value">{equity.annualized_volatility_pct.toFixed(1)}%</p>
          </div>
          <div>
            <p className="stat-label">Sharpe (vs Repo)</p>
            <p className="stat-value">{equity.estimated_sharpe.toFixed(3)}</p>
          </div>
        </div>

        {/* Drawdown gauge */}
        <div className="mb-4">
          <div className="flex justify-between text-xs text-slate-400 mb-1">
            <span>Drawdown from Peak: <strong className={equity.de_risk_triggered ? 'text-red-400' : 'text-slate-200'}>{equity.drawdown_from_peak_pct.toFixed(2)}%</strong></span>
            <span>Threshold: {equity.de_risk_threshold_pct}%</span>
          </div>
          <div className="h-3 bg-slate-700 rounded-full overflow-hidden">
            <div className={`h-full rounded-full transition-all ${equity.de_risk_triggered ? 'bg-red-500' : 'bg-amber-500'}`}
              style={{ width: `${drawdownBarWidth}%` }} />
          </div>
        </div>

        <div className={`px-4 py-3 rounded-lg text-sm font-medium ${equity.de_risk_triggered ? 'bg-red-900/40 text-red-300 border border-red-700' : 'bg-green-900/40 text-green-300 border border-green-700'}`}>
          {equity.action}
        </div>

        <div className="grid grid-cols-3 gap-4 mt-4">
          <div>
            <p className="stat-label">Current Equity</p>
            <p className="text-lg font-bold text-white">{fmt(equity.current_equity_notional_usd)}</p>
          </div>
          <div>
            <p className="stat-label">Recommended</p>
            <p className="text-lg font-bold text-amber-400">{fmt(equity.recommended_equity_usd)}</p>
          </div>
          <div>
            <p className="stat-label">Perm Capital Cap</p>
            <p className="text-lg font-bold text-slate-300">{fmt(equity.permanent_capital_cap_usd)}</p>
          </div>
        </div>
      </div>
    </div>
  )
}

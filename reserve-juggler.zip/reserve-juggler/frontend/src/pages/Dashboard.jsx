import { useEffect, useState } from 'react'
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid } from 'recharts'

const TIER_COLORS = ['#3b82f6', '#8b5cf6', '#10b981', '#f59e0b']
const TIER_LABELS = ['Cash', 'Repo', 'Bonds', 'Equities']

function fmt(n) {
  if (n >= 1e6) return `$${(n / 1e6).toFixed(1)}M`
  if (n >= 1e3) return `$${(n / 1e3).toFixed(1)}K`
  return `$${n.toFixed(0)}`
}

export default function Dashboard() {
  const [summary, setSummary] = useState(null)
  const [ts, setTs] = useState([])

  useEffect(() => {
    fetch('/api/summary').then(r => r.json()).then(setSummary)
    fetch('/api/timeseries?limit=168').then(r => r.json()).then(d => setTs(d.data || []))
  }, [])

  if (!summary) return <div className="text-slate-400 text-center mt-20">Loading data and training models… (~30s)</div>

  const alloc = summary.tier_allocation
  const pieData = [
    { name: 'Cash', value: alloc.cash_pct },
    { name: 'Repo', value: alloc.repo_pct },
    { name: 'Bonds', value: alloc.bonds_pct },
    { name: 'Equities', value: alloc.equities_pct },
  ]
  const reg = summary.regime
  const mkt = summary.market

  return (
    <div className="space-y-6">
      {/* Header row */}
      <div className="flex items-center gap-4 flex-wrap">
        <h1 className="text-2xl font-bold text-white">Treasury Dashboard</h1>
        <span className={`px-3 py-1 rounded-full text-sm font-bold ${reg.label === 'STRESS' ? 'bg-red-500/20 text-red-400 border border-red-500' : 'bg-green-500/20 text-green-400 border border-green-500'}`}>
          {reg.label} {reg.cusum_alert ? '⚠ CUSUM' : ''}
        </span>
        <span className="text-slate-400 text-sm">{summary.timestamp}</span>
      </div>

      {/* AUM + Yield Drag */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card">
          <p className="stat-label">Total AUM</p>
          <p className="stat-value">{fmt(summary.total_aum_usd)}</p>
        </div>
        <div className="card">
          <p className="stat-label">Repo Rate APY</p>
          <p className="stat-value">{mkt.repo_rate_apy_pct.toFixed(3)}%</p>
        </div>
        <div className="card">
          <p className="stat-label">Bond Yield</p>
          <p className="stat-value">{mkt.bond_yield_pct.toFixed(3)}%</p>
        </div>
        <div className="card bg-amber-900/30 border-amber-700">
          <p className="stat-label text-amber-400">Yield Drag / Day</p>
          <p className="stat-value text-amber-400">{fmt(summary.yield_drag.daily_cost_usd)}</p>
          <p className="text-xs text-amber-500 mt-1">{fmt(summary.yield_drag.hourly_cost_usd)}/hr of excess cash cost</p>
        </div>
      </div>

      {/* Allocation donut + Market */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <h2 className="text-sm font-semibold text-slate-300 mb-4">Tier Allocation</h2>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={pieData} dataKey="value" cx="40%" cy="50%" outerRadius={90} label={({ name, value }) => `${name} ${value.toFixed(0)}%`} labelLine={false}>
                {pieData.map((_, i) => <Cell key={i} fill={TIER_COLORS[i]} />)}
              </Pie>
              <Tooltip formatter={(v) => `${v.toFixed(1)}%`} contentStyle={{ background: '#1e293b', border: '1px solid #475569' }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex gap-4 mt-2 flex-wrap">
            {pieData.map((d, i) => (
              <div key={d.name} className="flex items-center gap-1.5 text-xs text-slate-300">
                <span className="w-3 h-3 rounded-full inline-block" style={{ background: TIER_COLORS[i] }} />
                {d.name}: {fmt(alloc[`${d.name.toLowerCase()}_usd`])}
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <h2 className="text-sm font-semibold text-slate-300 mb-4">Net Flow (Last 7 Days)</h2>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={ts.slice(-168)} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="timestamp" tick={false} />
              <YAxis tickFormatter={v => `${(v/1e6).toFixed(0)}M`} tick={{ fill: '#94a3b8', fontSize: 10 }} />
              <Tooltip formatter={v => fmt(v)} contentStyle={{ background: '#1e293b', border: '1px solid #475569' }} />
              <Line type="monotone" dataKey="net_flow_usd" stroke="#3b82f6" dot={false} strokeWidth={1.5} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Market snapshot */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card">
          <p className="stat-label">Stock Index</p>
          <p className="stat-value">{mkt.stock_price.toFixed(2)}</p>
        </div>
        <div className="card">
          <p className="stat-label">Stock Volatility</p>
          <p className="stat-value">{mkt.stock_vol_pct.toFixed(1)}%</p>
        </div>
        <div className="card">
          <p className="stat-label">Bond Price Index</p>
          <p className="stat-value">{mkt.bond_price_index.toFixed(3)}</p>
        </div>
        <div className="card">
          <p className="stat-label">Stress Probability</p>
          <p className={`stat-value ${reg.stress_probability > 0.5 ? 'text-red-400' : 'text-green-400'}`}>
            {(reg.stress_probability * 100).toFixed(1)}%
          </p>
        </div>
      </div>
    </div>
  )
}

import { useEffect, useState } from 'react'
import { ComposedChart, Area, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceArea } from 'recharts'

function fmt(n) {
  if (n >= 1e6) return `$${(n/1e6).toFixed(1)}M`
  return `$${n?.toFixed(0)}`
}

export default function Regime() {
  const [regime, setRegime] = useState(null)
  const [simResult, setSimResult] = useState(null)
  const [simParams, setSimParams] = useState({ multiplier: 3, start_hour: 22, duration: 6, cash: 50e6, repo: 300e6, bonds: 100e6, equities: 50e6 })
  const [simLoading, setSimLoading] = useState(false)

  useEffect(() => {
    fetch('/api/regime').then(r => r.json()).then(setRegime)
  }, [])

  const runSim = () => {
    setSimLoading(true)
    const p = simParams
    const url = `/api/simulate?withdrawal_multiplier=${p.multiplier}&shock_start_hour=${p.start_hour}&shock_duration_hours=${p.duration}&current_cash_usd=${p.cash}&current_repo_usd=${p.repo}&current_bonds_usd=${p.bonds}&current_equities_usd=${p.equities}`
    fetch(url, { method: 'POST' }).then(r => r.json()).then(d => { setSimResult(d); setSimLoading(false) })
  }

  if (!regime) return <div className="text-slate-400 text-center mt-20">Loading regime data…</div>

  const current = regime.current
  const history = regime.history || []

  // Sample 200 points for chart performance
  const step = Math.max(1, Math.floor(history.length / 200))
  const chartData = history.filter((_, i) => i % step === 0)

  const stressRegions = []
  let start = null
  chartData.forEach((d, i) => {
    if (d.regime === 1 && start === null) start = i
    if (d.regime === 0 && start !== null) { stressRegions.push([start, i - 1]); start = null }
  })
  if (start !== null) stressRegions.push([start, chartData.length - 1])

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Regime Detection & Stress Testing</h1>

      {/* Current regime */}
      <div className={`card border-2 ${current.label === 'STRESS' ? 'border-red-500' : 'border-green-500'}`}>
        <div className="flex items-center gap-4 flex-wrap">
          <div className={`w-4 h-4 rounded-full animate-pulse ${current.label === 'STRESS' ? 'bg-red-500' : 'bg-green-500'}`} />
          <h2 className="text-xl font-bold text-white">Current Regime: {current.label}</h2>
          <span className="text-slate-400 text-sm">{current.hours_in_current_state}h in this state</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
          <div>
            <p className="stat-label">Stress Probability</p>
            <p className="stat-value">{(current.stress_probability * 100).toFixed(1)}%</p>
          </div>
          <div>
            <p className="stat-label">CUSUM Alert</p>
            <p className={`stat-value ${current.cusum_alert ? 'text-red-400' : 'text-green-400'}`}>{current.cusum_alert ? 'YES' : 'NO'}</p>
          </div>
          <div>
            <p className="stat-label">Quantile Adjustment</p>
            <p className="stat-value text-amber-400">+{(current.quantile_adjustment * 100).toFixed(0)}%</p>
          </div>
          <div>
            <p className="stat-label">State</p>
            <p className="stat-value">{current.state}</p>
          </div>
        </div>
      </div>

      {/* Regime timeline */}
      <div className="card">
        <h2 className="text-sm font-semibold text-slate-300 mb-4">Full Year Regime Timeline (Green = Normal, Red bands = Stress)</h2>
        <ResponsiveContainer width="100%" height={220}>
          <ComposedChart data={chartData} margin={{ left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="timestamp" tick={false} />
            <YAxis tickFormatter={v => `${(v/1e6).toFixed(0)}M`} tick={{ fill: '#94a3b8', fontSize: 10 }} />
            <Tooltip
              contentStyle={{ background: '#1e293b', border: '1px solid #475569' }}
              formatter={(v, n) => n === 'net_flow' ? fmt(v) : v}
              labelFormatter={l => l}
            />
            {stressRegions.map(([s, e], i) => (
              <ReferenceArea key={i} x1={chartData[s]?.timestamp} x2={chartData[e]?.timestamp} fill="#ef4444" fillOpacity={0.15} />
            ))}
            <Area type="monotone" dataKey="net_flow" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.1} dot={false} strokeWidth={1} name="net_flow" />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* War Room Simulator */}
      <div className="card border-amber-600">
        <h2 className="text-base font-semibold text-amber-300 mb-4">⚔ War Room — Withdrawal Shock Simulator</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div>
            <label className="stat-label block mb-1">Withdrawal Multiplier</label>
            <input type="number" value={simParams.multiplier} min="1" max="20" step="0.5"
              onChange={e => setSimParams({ ...simParams, multiplier: +e.target.value })}
              className="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-white text-sm" />
          </div>
          <div>
            <label className="stat-label block mb-1">Start Hour (0-23)</label>
            <input type="number" value={simParams.start_hour} min="0" max="23"
              onChange={e => setSimParams({ ...simParams, start_hour: +e.target.value })}
              className="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-white text-sm" />
          </div>
          <div>
            <label className="stat-label block mb-1">Duration (hours)</label>
            <input type="number" value={simParams.duration} min="1" max="24"
              onChange={e => setSimParams({ ...simParams, duration: +e.target.value })}
              className="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-white text-sm" />
          </div>
          <div className="flex items-end">
            <button onClick={runSim} disabled={simLoading}
              className="w-full px-4 py-2 bg-amber-600 hover:bg-amber-500 rounded text-sm font-semibold text-white disabled:opacity-50">
              {simLoading ? 'Simulating…' : 'Run Simulation'}
            </button>
          </div>
        </div>

        {simResult && (
          <div className="mt-4">
            <div className="flex items-center gap-3 mb-3">
              <span className={`px-3 py-1 rounded-full text-sm font-bold ${simResult.survived ? 'bg-green-500/20 text-green-400 border border-green-500' : 'bg-red-500/20 text-red-400 border border-red-500'}`}>
                {simResult.survived ? '✓ SURVIVED' : '✗ FAILED — OVERDRAFT TRIGGERED'}
              </span>
              <span className="text-slate-400 text-sm">Total shock: {fmt(simResult.scenario.total_shock_usd)}</span>
              <span className="text-red-400 font-semibold text-sm">Total penalties: {fmt(simResult.total_penalty_usd)}</span>
            </div>

            {/* Cascade waterfall */}
            <div className="space-y-2">
              {simResult.cascade.map((tier, i) => (
                <div key={i} className="flex items-center gap-3 bg-slate-900 rounded-lg px-4 py-2">
                  <div className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">{i}</div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-200">{tier.tier}</p>
                    <div className="h-1.5 bg-slate-700 rounded mt-1">
                      <div className="h-full bg-blue-500 rounded" style={{ width: `${Math.min(tier.used_usd / simResult.scenario.total_shock_usd * 100, 100)}%` }} />
                    </div>
                  </div>
                  <div className="text-right text-xs">
                    <p className="text-white">{fmt(tier.used_usd)}</p>
                    {tier.penalty_usd > 0 && <p className="text-red-400">−{fmt(tier.penalty_usd)} ({tier.haircut_pct.toFixed(1)}%)</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

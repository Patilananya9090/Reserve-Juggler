import { useEffect, useState } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'

function fmt(n) {
  return `$${(n / 1e6).toFixed(1)}M`
}

const TIER_COLORS = { cash: '#3b82f6', repo: '#8b5cf6', bonds: '#10b981', equities: '#f59e0b' }

export default function Optimizer() {
  const [result, setResult] = useState(null)
  const [horizon, setHorizon] = useState(24)
  const [lambda, setLambda] = useState(2)
  const [loading, setLoading] = useState(false)

  const run = () => {
    setLoading(true)
    fetch(`/api/portfolio?horizon=${horizon}&risk_lambda=${lambda}`)
      .then(r => r.json())
      .then(d => { setResult(d); setLoading(false) })
  }

  useEffect(() => { run() }, [])

  const chartData = result ? [
    { name: 'Cash', value: result.allocations.cash_usd, fill: TIER_COLORS.cash },
    { name: 'Repo', value: result.allocations.repo_usd, fill: TIER_COLORS.repo },
    { name: 'Bonds', value: result.allocations.bonds_usd, fill: TIER_COLORS.bonds },
    { name: 'Equities', value: result.allocations.equities_usd, fill: TIER_COLORS.equities },
  ] : []

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Multi-Period CVaR Optimizer</h1>
      <p className="text-slate-400 text-sm">Maximize expected yield − λ · CVaR(95%) of cash shortfall over the planning horizon.</p>

      {/* Controls */}
      <div className="card flex flex-wrap gap-6 items-end">
        <div>
          <label className="stat-label block mb-2">Horizon (hours)</label>
          <div className="flex gap-2">
            {[24, 48, 72].map(h => (
              <button key={h} onClick={() => setHorizon(h)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${horizon === h ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'}`}>
                {h}h
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="stat-label block mb-2">Risk Aversion λ = {lambda}</label>
          <input type="range" min="0.5" max="10" step="0.5" value={lambda} onChange={e => setLambda(+e.target.value)}
            className="w-40 accent-blue-500" />
        </div>
        <button onClick={run} disabled={loading}
          className="px-5 py-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-sm font-semibold text-white transition-colors disabled:opacity-50">
          {loading ? 'Optimizing…' : 'Run Optimizer'}
        </button>
      </div>

      {result && (
        <>
          {/* KPI row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="card">
              <p className="stat-label">Expected Yield ({horizon}h)</p>
              <p className="stat-value text-green-400">{fmt(result.expected_yield_usd_horizon)}</p>
            </div>
            <div className="card">
              <p className="stat-label">Annualized Yield</p>
              <p className="stat-value">{result.annualized_yield_pct.toFixed(3)}%</p>
            </div>
            <div className="card">
              <p className="stat-label">CVaR 95% Shortfall</p>
              <p className="stat-value text-red-400">{fmt(Math.abs(result.cvar_95_usd))}</p>
            </div>
            <div className="card">
              <p className="stat-label">Total AUM</p>
              <p className="stat-value">{fmt(result.total_aum_usd)}</p>
            </div>
          </div>

          {/* Allocation chart */}
          <div className="card">
            <h2 className="text-sm font-semibold text-slate-300 mb-4">Optimized Tier Allocation</h2>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={chartData} margin={{ left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" tick={{ fill: '#94a3b8', fontSize: 12 }} />
                <YAxis tickFormatter={v => `${(v/1e6).toFixed(0)}M`} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <Tooltip formatter={v => fmt(v)} contentStyle={{ background: '#1e293b', border: '1px solid #475569' }} />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}
                  fill="#3b82f6"
                  label={{ position: 'top', fill: '#94a3b8', fontSize: 11, formatter: v => `${(v/1e6).toFixed(0)}M` }}>
                  {chartData.map((d, i) => (
                    <rect key={i} fill={d.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-4 gap-3 mt-4">
              {Object.entries(result.weights_pct).map(([tier, pct]) => (
                <div key={tier} className="text-center">
                  <p className="text-xs text-slate-400 capitalize">{tier}</p>
                  <p className="font-bold text-white">{pct.toFixed(1)}%</p>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  )
}
